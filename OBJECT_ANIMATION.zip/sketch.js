function setup() {
  createCanvas(400, 400);
  background(200, 240, 255); 

  fill(222, 184, 135); 
  stroke(150, 100, 50);
  triangle(200, 300, 170, 200, 230, 200);

  fill(255, 182, 193); 
  stroke(255, 105, 180);
  ellipse(200, 180, 80,); 
 
  fill(255, 0, 0);
  noStroke();
  ellipse(200, 140, 15,);
} 
